import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.activity.R

class MainActivity : AppCompatActivity() {
    lateinit var editText1: EditText
    lateinit var editText2: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
    }

    fun onCompareButtonClick(view: View) {
        val text1 = editText1.text.toString()
        val text2 = editText2.text.toString()

        if (text1 == text2) {
            // Los textos coinciden
            // Puedes mostrar un mensaje, cambiar colores, etc.
        } else {
            // Los textos no coinciden
            // Puedes mostrar un mensaje, cambiar colores, etc.
        }
    }
    fun compareTexts(): Boolean {
        val text1 = editText1.text.toString()
        val text2 = editText2.text.toString()

        return text1 == text2
    }


}

