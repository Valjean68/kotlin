import org.junit.Assert
import org.junit.Test

class MainActivityTest {

    @Test
    fun testCompareTextsEqual() {
        val activity = MainActivity()
        activity.editText1.setText("Hello")
        activity.editText2.setText("Hello")

        val result = activity.compareTexts()
        Assert.assertTrue(result)
    }

    @Test
    fun testCompareTextsNotEqual() {
        val activity = MainActivity()
        activity.editText1.setText("Hello")
        activity.editText2.setText("World")

        val result = activity.compareTexts()
        Assert.assertFalse(result)
    }
}
